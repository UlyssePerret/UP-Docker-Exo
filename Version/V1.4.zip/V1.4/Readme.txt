Structure du projet
Sur la racine sont present
Les fichiers :
* docker-compose.yml -> décrivant l’orchestration de l’exécution des containeurs.
* Dockerfile -> description d’image ;
* Exercice_Docker.pdg -> Sujet
_
Les dossiers :
dossier php
Version : les versions précédente

Dernier version V1.1

Prerequis :
- Avoir Docker installer

Aide pour l'installation de docker
https://openclassrooms.com/fr/courses/2035766-optimisez-votre-deploiement-en-creant-des-conteneurs-avec-docker/6211390-installez-docker-sur-votre-poste
install docker sur window :: https://docs.docker.com/docker-for-windows/install/
install docker sur mac : https://docs.docker.com/docker-for-mac/install/
install ubuntu :  https://docs.docker.com/engine/install/ubuntu/
install docker sur Windows Home : https://docs.docker.com/docker-for-windows/install-windows-home/

Etape installation du proejt:
- lancer le terminal 
- Aller grace à pwd sur l'archicture et aller au dossier exercice  où se trouve ce fichier et le Dockerfile (racine)
- Sur le terminal lancer : docker-compose up
- ajouter la base de données SQL ProjetSQL.sql (ddans le dossier sql)


Une fois fini vous pouvez nettoyer les images docker avec docker system prune

Changelog
V 1.0 - Samedi 12 et 13
-> Premier reflexion sur l'exercice Docker
-> Création du repertoire FormExo1
-> Ajout du sujet Exercice_Docker.pdg
-> Création du fichier Dokerfile
-> Création du fichier docker-compose.yml
-> Demande de conseil des étapes à suivre fmichaud@9fevrier.com le 15/09/2020

V 1.1 _ Mardi 15 - Mercredi 16
Cours SQL
- Creation du fichier projetSQL.SQL
- Création de la base projetSQL et l'exporter pour sauvegarde
- Test de ligne de commandes sur la base de donnée (utilisation de la base, test jointures, recherche)

V 1.2 - Dimanche 20 Septembre

Création du dossier verison 
Stockage des fichiers actuelles pour sauvegarde et base de travaille (nommée V1.1 - zip)

Décision de faire un Readme.txt pour noter et ajouter les améliorations, ajouts et changement du projet pour la formation Docker.
Il s'agit fichier que vous lisez actuellement.

Création du Readme.txt 
	- Ajout du structure du porjet
	- Ajout du prerequis : avoir docker et docker compose installer
	- Ajout Etape installation
	- Ajout du changelog actuelle

Test état du projet actuelle
Lancement sur terminal
- Aller sur le fichier
- Mettre nginx et node : 
  - docker pull nginx 
  - docker pull node
- installer pip : sudo easy_install pip
- lancer le docker compose : docker-compose up
se connecter sur l'adresse : http://localhost:8282/index.php
- Remarquer que la base de donnée n'as pas été mise, demander à la mettre sur l'installation

Minimum attendu pour V 2.0
- 1 Serveur frontal HTTP pour service PHP intréprétées : A FAIRE
- 1 serveur de base de donéne MYSQL ou MariaDB en charge de la persistance des donénes : OK (local)
- 1 fichier php : OK
- 1 fichier dockerfile : OK
- 1 fichier docker-compose : OK

Etape a faire
- Installer un serveur frontal HTTP pour les pages PHP
-> Passer en v 2.0 quand fini

Amelioration éventuelle
- Installer serveur de base de donéne MYSQL ou MariaDB si possible hebergement
- Faire en sorte que l'installation de la base de données soit sur le fichier Dokerfile

Stockage de tout les éléments, de la base de travaille dans le dosseir V1.2
-> Passe en version 1.3

V 1.3 - Dimanche 20 Septembre - Matin
- Installer un serveur frontal HTTP pour les pages PHP ?

Rappel : Docker fait que des environnement locaux
-> Le serveur MYSQL est ok du coup
il faut faire un serveur HTTP pour le service PHP sur le docker-compose.yml

Idee : Ajouter sur docker-compose.yml le serveur HTTP

Amelioration du Readme.txt

Pour httpd
- test docker pull httpd : ok
- test ajout sur Dokerfile  : Ok
- test docker-compose.yml : ?

Modification du Dokerfile - modificaiton avec le cours openclassroom
debian:9 -> non pas pertinent on se remet sur nginx
Nginx permet d'avoir des process tel que apache 
Modification du docker-compos.yml  - modificaiton avec le cours openclassroom
création du fichier .dockerignore (voir avec ls -a)

Test travaille sur Dokerfile
Stockage de tout les éléments, de la base de travaille dans le dosseir V1.3
V1.4 - Dimanche 20 Septembre - Aprem
Creation register


test de mettre sur le hub
ulysseperret/exo1dockerv14
Docker Hub -> Terminal
docker push ulysseperret/exo1dockerv14:tagname ->NO

Temrinal -> Hub ?
formexo1_db_1 ?
 docker push ulysseperret/exo1dockerv14:tagname -> NO

Hub tutorial?
docker tag ulysseperret:tagname new-repo:tagname  -> NO

ASK PEOPLE

Stockage de tout les éléments, de la base de travaille dans le dosseir V1.4
