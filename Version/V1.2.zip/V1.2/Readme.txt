Structure du projet
Sur la racine sont present
Les fichiers :
* docker-compose.yml -> décrivant l’orchestration de l’exécution des containeurs.
* Dockerfile -> description d’image ;
* Exercice_Docker.pdg -> Sujet
_
Les dossiers :
dossier php
Version : les versions précédente

Dernier version V1.1

Prerequis :
- Avoir Docker installer

Etape installation
- Aller grace à pwd sur l'archicture du fichier du travail où se trouve le Dockerfile
- Lancer docker-compose up sur le terminal
- ajouter la base de données SQL ProjetSQL.sql (ddans le dossier sql)

Changelog
V 1.0 - Samedi 12 et 13
-> Premier reflexion sur l'exercice Docker
-> Demande de conseil des étapes à suivre fmichaud@9fevrier.com le 15/09/2020
-> Création du fichier Dokerfile

V 1.1 _ Mardi 15 - Mercredi 16
Cours SQL
- Creation du fichier projetSQL
- Création de la base projetSQL.SQL

V 1.2 - Dimanche 20 Septembre

Création du dossier verison 
Stockage des fichiers actuelles pour sauvegarde et base de travaille (nommée V1.1 - zip)

Décision de faire un Readme.txt pour noter et ajouter les améliorations, ajouts et changement du projet pour la formation Docker (fichier que vous lisez actuellement)

Création du Readme.txt 
	- Ajout du structure du porjet
	- Ajout du prerequis : avoir docker et docker compose installer
	- Ajout Etape installation
	- Ajout du changelog actuelle

Test état du projet actuelle
Lancement sur terminal
- Aller sur le fichier
- Mettre nginx et node : 
  - docker pull nginx 
  - docker pull node
- installer pip : sudo easy_install pip
- lancer le docker compose : docker-compose up
se connecter sur l'adresse : http://localhost:8282/index.php
- Remarquer que la base de donnée n'as pas été mise, demander à la mettre sur l'installation

Minimum attendu pour V 2.0
- 1 Serveur frontal HTTP pour service PHP intréprétées : A FAIRE
- 1 serveur de base de donéne MYSQL ou MariaDB en charge de la persistance des donénes : OK (local)
- 1 fichier php : OK
- 1 fichier dockerfile : OK
- 1 fichier docker-compose : OK

Etape a faire
- Installer un serveur frontal HTTP pour les pages PHP
-> Passer en v 2.0 quand fini

Amelioration éventuelle
- Installer serveur de base de donéne MYSQL ou MariaDB si possible hebergement
- Faire en sorte que l'installation de la base de données soit sur le fichier Dokerfile

Stockage de tout les éléments, de la base de travaille dans le dosseir V1.2
-> Passe en version 1.3
