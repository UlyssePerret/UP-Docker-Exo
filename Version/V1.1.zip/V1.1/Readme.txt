Structure du projet
Sur la racine sont present
Les fichiers :
* docker-compose.yml -> décrivant l’orchestration de l’exécution des containeurs.
* Dockerfile -> description d’image ;
* Exercice_Docker.pdg -> Sujet
_
Les dossiers :
dossier php
Version : les versions précédente

Dernier version V1.1
Prerequis :
- Avoir Docker installer
- mettre nginx
- mettre node et nginx
- Aller grace à pwd sur l'archicture du fichier du travail ou se trouve le Dockerfile
- Faire Docker build -t todo-app

Exécution de l’application nécessite a minima :
- Serveur frontal HTTP, en charge de servir les pages PHP interprés : A faire
- Base de donnée : fournir par le  docker-compose.yml 
	-> Pour l'instant locale

A FAIRE
- Vérifier l'état du projet actuelle
- Installer un serveur frontal HTTP pour les pages PHP

Changelog
V 1.0 - Samedi 12 et 13
-> Premier reflexion sur l'exercice Docker
-> Demande de conseil des étapes à suivre fmichaud@9fevrier.com
- Création du fichier Dokerfile
- 

V 1.1 _ Mardi 15 - Mercredi 16
Cours SQL
- Creation du fichier projetSQL

V 1.2 - Dimanche 20 Septembre
Décision de faire un Readme.txt pour noter et ajouter les améliorations, ajouts et changement du projet pour la formation Docker

- Création du Readme.txt
	- Ajout d'un changelog
	- Ajout d'une structure du proejt
	- Faire une instation pour l'execution du projet
